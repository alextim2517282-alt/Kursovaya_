﻿using System;

namespace AutoSalon
{
    class Car
    {
        // Поля (закрытые)
        private string brand;       // марка
        private string bodyType;    // тип кузова
        private string country;     // страна
        private int year;           // год выпуска
        private decimal price;      // цена
    

        // Свойства (доступ к полям)
        public string Brand
        {
            get { return brand; }
            set { brand = value; }
        }

        public string BodyType
        {
            get { return bodyType; }
            set { bodyType = value; }
        }

        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        // Конструктор
        public Car(string brand, string bodyType, string country, int year, decimal price)
        {
            this.brand = brand;
            this.bodyType = bodyType;
            this.country = country;
            this.year = year;
            this.price = price;
        }

        // Метод для вычисления возраста автомобиля (в годах)
        public int Age()
        {
            int currentYear = DateTime.Now.Year;
            return currentYear - year;
        }

        // Метод для вывода информации об автомобиле (одна строка)
        public string GetInfo()
        {
            return $"{brand,-15} | {bodyType,-12} | {country,-12} | {year,4} г. | {price,10:C2} | возраст: {Age()} лет";
        }

        // Переопределение ToString() для удобства вывода
        public override string ToString()
        {
            return GetInfo();
        }
    }
}