﻿using System;
using System.Linq;

namespace AutoSalon
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Title = "Автосалон - Каталог автомобилей";

            Catalog catalog = new Catalog("Мой каталог");
            string dataFile = "autosalon.txt";

            // Попытка загрузить данные при старте
            catalog.LoadFromFile(dataFile);

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n========== МЕНЮ ==========");
                Console.WriteLine("1. Загрузить данные из файла");
                Console.WriteLine("2. Сохранить данные в файл");

                Console.WriteLine("3. Добавить автомобиль");
                Console.WriteLine("4. Удалить автомобиль по индексу");
                Console.WriteLine("5. Вывести все автомобили");

                Console.WriteLine("6. Определить возраст каждого автомобиля");
                Console.WriteLine("7. Определить средний возраст автомобилей");
                Console.WriteLine("8. Вывести самый дорогой автомобиль");
                Console.WriteLine("9. Вывести автомобили, упорядоченные по году выпуска (от ранних)");
                Console.WriteLine("0. Выход");
                Console.Write("Ваш выбор: ");



                string choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            catalog.LoadFromFile(dataFile);
                            break;
                        case "2":
                            catalog.SaveToFile(dataFile);



                            break;
                        case "3":
                            AddCarInteractive(catalog);
                            break;
                        case "4":
                            RemoveCarInteractive(catalog);
                            break;
                        case "5":
                            catalog.PrintAllCars();

                            break;
                        case "6":
                            ShowAllAges(catalog);
                            break;
                        case "7":
                            ShowAverageAge(catalog);
                            break;
                        case "8":

                            ShowMostExpensiveCar(catalog);
                            break;
                        case "9":
                            ShowCarsSortedByYear(catalog);
                            break;
                        case "0":
                            exit = true;
                            Console.WriteLine("До свидания!");
                            break;
                        default:
                            Console.WriteLine("Неверный ввод, попробуйте снова.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }

                if (!exit)
                {
                    Console.Write("\nНажмите любую клавишу для продолжения...");
                    Console.ReadKey();
                }
            }
        }

        static void AddCarInteractive(Catalog catalog)
        {
            Console.WriteLine("\n--- Добавление нового автомобиля ---");
            try
            {


                Console.Write("Марка: ");
                string brand = Console.ReadLine();

                Console.Write("Тип кузова: ");
                string bodyType = Console.ReadLine();
                Console.Write("Страна: ");
                string country = Console.ReadLine();

                Console.Write("Год выпуска: ");
                int year = int.Parse(Console.ReadLine());
                Console.Write("Цена (в рублях): ");
                decimal price = decimal.Parse(Console.ReadLine());

                Car newCar = new Car(brand, bodyType, country, year, price);
                catalog.AddCar(newCar);
                Console.WriteLine("Автомобиль успешно добавлен.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка: неверный формат числа (год или цена).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void RemoveCarInteractive(Catalog catalog)
        {
            if (catalog.CarCount == 0)

            {

                Console.WriteLine("Каталог пуст, нечего удалять.");
                return;
            }
            Console.Write($"Введите индекс автомобиля для удаления (0..{catalog.CarCount - 1}): ");
            if (int.TryParse(Console.ReadLine(), out int index))
            {
                try
                {
                    catalog.RemoveCar(index);
                    Console.WriteLine("Автомобиль удалён.");
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Неверный индекс.");
                }
            }

            else
            {
                Console.WriteLine("Неверный ввод индекса.");
            }
        }

        static void ShowAllAges(Catalog catalog)
        {
            var ages = catalog.GetAgesOfAllCars();
            if (ages.Count == 0)
            {
                Console.WriteLine("Нет автомобилей в каталоге.");
                return;
            }
            Console.WriteLine("\n--- Возраст каждого автомобиля ---");
            foreach (string info in ages)
                Console.WriteLine(info);
        }

        static void ShowAverageAge(Catalog catalog)
        {
            double avg = catalog.GetAverageAge();
            if (catalog.CarCount == 0)
                Console.WriteLine("Нет автомобилей для расчёта среднего возраста.");
            else
                Console.WriteLine($"Средний возраст автомобилей в каталоге: {avg:F1} лет");
        }

        static void ShowMostExpensiveCar(Catalog catalog)
        {
            Car mostExpensive = catalog.GetMostExpensiveCar();
            if (mostExpensive == null)
            {
                Console.WriteLine("Каталог пуст.");
                return;
            }
            Console.WriteLine("\n--- Самый дорогой автомобиль ---");
            Console.WriteLine(mostExpensive.GetInfo());
        }

        static void ShowCarsSortedByYear(Catalog catalog)
        {
            var sorted = catalog.GetCarsSortedByYear();
            if (sorted.Count == 0)
            {
                Console.WriteLine("Нет автомобилей для сортировки.");
                return;
            }
            Console.WriteLine("\n--- Автомобили, упорядоченные по году выпуска (от ранних) ---");
            Console.WriteLine("Марка          | Тип кузова   | Страна       | Год      | Цена           | Возраст");
            Console.WriteLine(new string('-', 85));
            foreach (Car car in sorted)
                Console.WriteLine($"{car.Brand,-15} | {car.BodyType,-12} | {car.Country,-12} | {car.Year,4} г. | {car.Price,10:C2} | {car.Age()} лет");
        }
    }
}