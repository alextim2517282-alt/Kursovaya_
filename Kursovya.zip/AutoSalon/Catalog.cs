﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AutoSalon
{
    class Catalog
    {
        private string name;                // название каталога
        private List<Car> cars;             // коллекция автомобилей

        // Свойство для названия каталога
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        // Свойство для количества автомобилей (только чтение)
        public int CarCount
        {
            get { return cars.Count; }
        }

        // Индексатор для доступа к автомобилю по индексу
        public Car this[int index]
        {
            get
            {
                if (index < 0 || index >= cars.Count)
                    throw new IndexOutOfRangeException("Неверный индекс автомобиля.");
                return cars[index];
            }
            set
            {
                if (index < 0 || index >= cars.Count)
                    throw new IndexOutOfRangeException("Неверный индекс автомобиля.");
                cars[index] = value;
            }
        }

        // Конструктор
        public Catalog(string name)
        {
            this.name = name;
            cars = new List<Car>();
        }

        // Добавление автомобиля
        public void AddCar(Car car)
        {
            if (car == null)
                throw new ArgumentNullException("Автомобиль не может быть пустым.");
            cars.Add(car);
        }

        // Удаление автомобиля по индексу
        public void RemoveCar(int index)
        {
            if (index < 0 || index >= cars.Count)
                throw new IndexOutOfRangeException("Неверный индекс автомобиля.");
            cars.RemoveAt(index);
        }

        // Возраст каждого автомобиля (возвращает список строк)
        public List<string> GetAgesOfAllCars()
        {
            List<string> result = new List<string>();
            for (int i = 0; i < cars.Count; i++)
            {
                result.Add($"{cars[i].Brand} {cars[i].BodyType} - возраст: {cars[i].Age()} лет");
            }
            return result;
        }

        // Средний возраст автомобилей
        public double GetAverageAge()
        {
            if (cars.Count == 0)
                return 0;
            int totalAge = 0;
            foreach (var car in cars)
                totalAge += car.Age();
            return (double)totalAge / cars.Count;
        }

        // Самый дорогой автомобиль (возвращает Car или null)
        public Car GetMostExpensiveCar()
        {
            if (cars.Count == 0)
                return null;
            return cars.OrderByDescending(c => c.Price).First();
        }

        // Автомобили, упорядоченные по году выпуска (от самых ранних)
        public List<Car> GetCarsSortedByYear()
        {
            return cars.OrderBy(c => c.Year).ToList();
        }

        // Вывод всех автомобилей
        public void PrintAllCars()
        {
            if (cars.Count == 0)
            {
                Console.WriteLine("Каталог пуст.");
                return;
            }
            Console.WriteLine($"\nКаталог \"{name}\" | Всего автомобилей: {cars.Count}\n");
            Console.WriteLine("Марка          | Тип кузова   | Страна       | Год      | Цена           ");
            Console.WriteLine(new string('-', 75));
            foreach (var car in cars)
            {
                Console.WriteLine(car.GetInfo());
            }
            Console.WriteLine();
        }

        // Сохранение каталога в текстовый файл
        public void SaveToFile(string filename)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.UTF8))
                {
                    sw.WriteLine(name);
                    sw.WriteLine(cars.Count);
                    foreach (Car car in cars)
                    {
                        sw.WriteLine(car.Brand);
                        sw.WriteLine(car.BodyType);
                        sw.WriteLine(car.Country);
                        sw.WriteLine(car.Year);
                        sw.WriteLine(car.Price);
                    }
                }
                Console.WriteLine($"Данные успешно сохранены в файл \"{filename}\".");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении файла: {ex.Message}");
            }
        }

        // Загрузка каталога из текстового файла
        public void LoadFromFile(string filename)
        {
            try
            {
                if (!File.Exists(filename))
                {
                    Console.WriteLine($"Файл \"{filename}\" не найден. Будет создан пустой каталог.");
                    return;
                }

                using (StreamReader sr = new StreamReader(filename, System.Text.Encoding.UTF8))
                {
                    name = sr.ReadLine();
                    int count = int.Parse(sr.ReadLine());
                    cars.Clear();

                    for (int i = 0; i < count; i++)
                    {
                        string brand = sr.ReadLine();
                        string bodyType = sr.ReadLine();
                        string country = sr.ReadLine();
                        int year = int.Parse(sr.ReadLine());
                        decimal price = decimal.Parse(sr.ReadLine());
                        cars.Add(new Car(brand, bodyType, country, year, price));
                    }
                }
                Console.WriteLine($"Данные успешно загружены из файла \"{filename}\".");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке файла: {ex.Message}");
                Console.WriteLine("Будет создан пустой каталог.");
            }
        }
    }
}